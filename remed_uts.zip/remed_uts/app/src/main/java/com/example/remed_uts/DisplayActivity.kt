package com.example.remed_uts

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class DisplayActivity() : AppCompatActivity() {
    private var displayTextView: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)
        displayTextView = findViewById(R.id.displayTextView)
        val userInput = intent.getStringExtra("userInput")
        val watchFor = intent.getStringExtra("watchFor")
        val genres = intent.getStringExtra("genres")
        val year = intent.getStringExtra("year")
        val duration = intent.getStringExtra("duration")
        displayTextView.setText("User Input: " + userInput + "\n"
                    + "Watch For: " + watchFor + "\n"
                    + "Genres: " + genres + "\n"
                    + "Year: " + year + "\n"
                    + "Duration: " + duration
        )
    }
}