package com.example.remed_uts

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity


class MainActivity2 : AppCompatActivity() {
    private var userInputEditText: EditText? = null
    private var adultRadioButton: RadioButton? = null
    private var kidsRadioButton: RadioButton? = null
    private var thrillerCheckBox: CheckBox? = null
    private var horrorCheckBox: CheckBox? = null
    private var actionCheckBox: CheckBox? = null
    private var romanceCheckBox: CheckBox? = null
    private var comedyCheckBox: CheckBox? = null
    private var fantasyCheckBox: CheckBox? = null
    private var yearSpinner: Spinner? = null
    private var hourSpinner: Spinner? = null
    private var minuteSpinner: Spinner? = null
    private var okButton: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        userInputEditText = findViewById(R.id.userInputEditText)
        adultRadioButton = findViewById(R.id.adultRadioButton)
        kidsRadioButton = findViewById(R.id.kidsRadioButton)
        thrillerCheckBox = findViewById(R.id.thrillerCheckBox)
        horrorCheckBox = findViewById(R.id.horrorCheckBox)
        actionCheckBox = findViewById(R.id.actionCheckBox)
        romanceCheckBox = findViewById(R.id.romanceCheckBox)
        comedyCheckBox = findViewById(R.id.comedyCheckBox)
        fantasyCheckBox = findViewById(R.id.fantasyCheckBox)
        yearSpinner = findViewById(R.id.yearSpinner)
        hourSpinner = findViewById(R.id.hourSpinner)
        minuteSpinner = findViewById(R.id.minuteSpinner)
        okButton = findViewById(R.id.okButton)
        okButton.setOnClickListener(View.OnClickListener {
            val userInput = userInputEditText.getText().toString()
            val watchFor = if (adultRadioButton.isChecked()) "Adult (17+)" else "Kids"
            val genres = StringBuilder()
            if (thrillerCheckBox.isChecked()) genres.append("Thriller ")
            if (horrorCheckBox.isChecked()) genres.append("Horror ")
            if (actionCheckBox.isChecked()) genres.append("Action ")
            if (romanceCheckBox.isChecked()) genres.append("Romance ")
            if (comedyCheckBox.isChecked()) genres.append("Comedy ")
            if (fantasyCheckBox.isChecked()) genres.append("Fantasy ")
            val year = yearSpinner.getSelectedItem().toString()
            val duration = hourSpinner.getSelectedItem()
                .toString() + " hours " + minuteSpinner.getSelectedItem().toString() + " minutes"
            val intent = Intent(
                this@MainActivity2,
                DisplayActivity::class.java
            )
            intent.putExtra("userInput", userInput)
            intent.putExtra("watchFor", watchFor)
            intent.putExtra("genres", genres.toString())
            intent.putExtra("year", year)
            intent.putExtra("duration", duration)
            startActivity(intent)
        })
    }
}